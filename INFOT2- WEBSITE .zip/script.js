let currentImageIndex = 0;

const images = document.querySelectorAll(".thumbnail");
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");

// Open the lightbox
function openLightbox(index) {
    if (images.length === 0) return;

    currentImageIndex = index;
    lightbox.style.display = "flex";
    showImage(currentImageIndex);
}

// Close the lightbox
function closeLightbox() {
    lightbox.style.display = "none";
}

// Display the selected image
function showImage(index) {
    if (images.length === 0) return;

    currentImageIndex = index;
    lightboxImage.src = images[currentImageIndex].src;
    lightboxImage.alt = images[currentImageIndex].alt || "Gallery image";
}

// Change to the previous or next image
function changeImage(direction) {
    if (images.length === 0) return;

    currentImageIndex += direction;

    // Return to the last image or first image when needed
    if (currentImageIndex < 0) {
        currentImageIndex = images.length - 1;
    } else if (currentImageIndex >= images.length) {
        currentImageIndex = 0;
    }

    showImage(currentImageIndex);
}

// Make every thumbnail clickable
images.forEach((img, index) => {
    img.addEventListener("click", () => {
        openLightbox(index);
    });
});

// Keyboard controls
document.addEventListener("keydown", function(event) {
    if (!lightbox || lightbox.style.display === "none") return;

    if (event.key === "Escape") {
        closeLightbox();
    } else if (event.key === "ArrowRight") {
        changeImage(1);
    } else if (event.key === "ArrowLeft") {
        changeImage(-1);
    }
});